# Integration Guide — @siddhi-life/game-meta

This package provides all server connection infrastructure (WebSocket rooms, voice, state sync) so game teams can focus on game logic. The PWA uses `game-loader` to mount game components; game teams never interact with the PWA directly.

---

## Quick Start

### 1. Install

```bash
npm install @siddhi-life/game-meta
```

### 2. Create a game component

```typescript
// src/MyGame.tsx
import { useGameRoom } from '@siddhi-life/game-meta'
import type { GameProps } from '@siddhi-life/game-meta'

export default function MyGame({ serverUrl, token, roomId, onExit, onEvent }: GameProps) {
  const {
    isConnected,
    players,
    testData,
    latency,
    voiceToken,
    error,
    sendStatePatch,
    sendPing,
    retry,
  } = useGameRoom({
    serverUrl,   // always from GameProps — game-loader provides this
    token,
    roomId,
    gameId: 'my-game',
    enableVoice: false,
    onEvent,
  })

  if (error) return <p>Error: {error.message}</p>

  return (
    <div>
      <p>Connected: {isConnected ? 'Yes' : 'No'} | Players: {players.length}</p>
      <button onClick={() => sendStatePatch('move', JSON.stringify({ x: 1 }))}>Move</button>
      <button onClick={sendPing}>Ping ({latency ?? '-'}ms)</button>
      <button onClick={onExit}>Exit</button>
    </div>
  )
}
```

### 3. Export your component

```typescript
// src/index.ts
import MyGame from './MyGame.js'

export const metadata = {
  id: 'my-game',
  name: 'My Game',
  description: 'Does cool things',
  minPlayers: 1,
  maxPlayers: 4,
}

export default MyGame
```

---

## Architecture

```
game-loader ──── GameProps (serverUrl, token, roomId) ────▶ YourGame.tsx
                                                                 │
                                                         useGameRoom(...)
                                                                 │
                                                   GameRoomConnectionManager
                                                   (module-level singleton)
                                                                 │
                                                   ColyseusRoomConnection
                                                   (WebSocket + Colyseus)
```

`GameConnectionProvider` is available as a React context alternative to `useGameRoom` when you need to share connection state across a component tree:

```typescript
import { GameConnectionProvider, useGameConnection } from '@siddhi-life/game-meta'

// Wrap a subtree
<GameConnectionProvider config={{ serverUrl, token, gameId: 'my-game' }}>
  <ScoreBoard />
  <Board />
</GameConnectionProvider>

// In any child component
function ScoreBoard() {
  const { players, latency } = useGameConnection()
  // ...
}
```

---

## GameProps Contract

**All fields are provided by game-loader.** Game components must never hardcode or fetch these values.

```typescript
interface GameProps {
  serverUrl: string             // WebSocket URL — always from game-loader
  token: string                 // User auth JWT
  roomId?: string               // Join existing room; omit to create new
  roomPassword?: string         // Private rooms (future)
  onExit: () => void            // Call exactly once when game ends
  onEvent: (event: GameEvent) => void  // Emit lifecycle events
}
```

---

## useGameRoom Hook

The primary hook for all game connection logic:

```typescript
import { useGameRoom } from '@siddhi-life/game-meta'

const {
  // State
  isConnected,             // boolean
  sessionId,               // string | null — your Colyseus session ID
  players,                 // PlayerInfo[] — all connected players
  testData,                // Record<string, string> — synced key-value state
  latency,                 // number | null — round-trip ms
  voiceToken,              // string | null — LiveKit JWT (when enableVoice: true)
  error,                   // { code: number; message: string } | null

  // Send operations
  sendStatePatch,          // (key: string, value: string) => void
  sendPing,                // () => void — triggers latency update
  sendRandomPatch,         // () => void — debug: sends a random patch
  mutePlayer,              // (sessionId: string) => void
  unmutePlayer,            // (sessionId: string) => void
  muteAllExcept,           // (sessionId?: string) => void

  // Lifecycle
  disconnect,              // () => void
  retry,                   // () => void — re-attempt after connection failure
} = useGameRoom({
  serverUrl: string,       // required — WebSocket base URL
  token: string,           // required — auth JWT
  gameId?: string,         // Colyseus room name
  roomId?: string,         // join existing room
  enableVoice?: boolean,   // request LiveKit token (default: false)
  debug?: {                // verbose logging per layer
    connection?: boolean
    messages?: boolean
    stateSync?: boolean
  },
  onEvent: (event: GameEvent) => void,
})
```

### PlayerInfo

```typescript
interface PlayerInfo {
  sessionId: string
  name?: string
  joinedAt: number
  isConnected: boolean
}
```

### State sync

`testData` is a flat `Record<string, string>` of all patches received from the server. Use structured keys and JSON values for complex state:

```typescript
sendStatePatch('move:0-1', JSON.stringify({ row: 0, col: 1, player: 'X' }))

// Reading:
const moves = Object.entries(testData)
  .filter(([k]) => k.startsWith('move:'))
  .map(([, v]) => JSON.parse(v))
```

---

## GameEvent Types

`GameEvent` is a strict discriminated union — all payload fields are required:

```typescript
type GameEvent =
  | { type: 'START';     payload: { roomId: string; sessionId: string } }
  | { type: 'END';       payload: { reason: string; code: number } }
  | { type: 'ERROR';     payload: { code: number; message: string } }
  | { type: 'ROOM_INFO'; payload: Record<string, unknown> }
```

**When to emit each event (game components):**

| Event | When | Required payload fields |
|-------|------|------------------------|
| `START` | WebSocket room joined | `roomId`, `sessionId` |
| `END` | Clean exit (player or server) | `reason` (string), `code` (number) |
| `ERROR` | Unrecoverable error | `code` (number), `message` (string) |
| `ROOM_INFO` | Optional info (voice token, etc.) | any `Record<string, unknown>` |

TypeScript narrows the payload automatically per branch:

```typescript
const onEvent = (event: GameEvent) => {
  switch (event.type) {
    case 'START':
      saveRoomId(event.payload.roomId)       // string ✓
      break
    case 'END':
      onExit()                               // event.payload.code: number ✓
      break
    case 'ERROR':
      showError(event.payload.message)       // string ✓
      break
    case 'ROOM_INFO':
      handleInfo(event.payload)              // Record<string, unknown> ✓
      break
  }
}
```

---

## Voice Chat Integration

Enable voice by passing `enableVoice: true` to `useGameRoom`. The hook returns a `voiceToken` (LiveKit JWT) when the server grants one:

```typescript
const { voiceToken, sessionId } = useGameRoom({
  serverUrl,
  token,
  gameId: 'my-game',
  enableVoice: true,
  onEvent,
})

// voiceToken is the LiveKit JWT — pass it to useVoice
// sessionId matches the LiveKit participant identity
```

### useVoice Hook

```typescript
import { useVoice } from '@siddhi-life/game-meta'

function VoiceChat({ voiceToken, livekitUrl }: { voiceToken: string; livekitUrl: string }) {
  const {
    isConnected,              // boolean
    isMuted,                  // boolean — self mic muted
    isMicrophoneEnabled,      // boolean — mic permission granted
    remoteParticipants,       // RemoteParticipant[]
    speakingParticipants,     // Set<string> — currently speaking participant identities
    toggleMute,               // () => void
    setRemoteVolume,          // (identity: string, volume: number) => void
    setAllRemoteVolume,       // (volume: number) => void
    disconnect,               // () => void
  } = useVoice({
    token: voiceToken,
    serverUrl: livekitUrl,
    onConnected: () => console.log('Voice connected'),
    onDisconnected: () => console.log('Voice disconnected'),
    onError: (err) => console.error('Voice error:', err),
  })
}
```

**Voice architecture:**

```
useGameRoom ──▶ voiceToken (LiveKit JWT)
                     │
                     ▼
                useVoice ──▶ LiveKit Cloud ──▶ Audio elements (auto-created)
```

**Key details:**
- Audio elements are created and attached to the DOM automatically on `trackSubscribed`
- LiveKit identity equals the Colyseus `sessionId` — no mapping needed
- Microphone auto-enables on connect (browser permission requested)

---

## MetaGameComponent

The package's default export is a full reference UI that wires together `useGameRoom` and `useVoice`. Game teams can use it as-is or as a template:

```typescript
import MetaGameComponent from '@siddhi-life/game-meta'

// All props come from GameProps — provided by game-loader
<MetaGameComponent
  serverUrl={serverUrl}
  token={token}
  roomId={roomId}
  gameId="meta-game"
  enableVoice={false}
  onExit={onExit}
  onEvent={onEvent}
/>
```

---

## Error Handling

Connection errors surface via the `error` field from `useGameRoom`:

```typescript
const { error, retry } = useGameRoom({ ... })

// error is { code: number; message: string } | null
if (error) {
  return (
    <div>
      <p>Error {error.code}: {error.message}</p>
      <button onClick={retry}>Retry</button>
    </div>
  )
}
```

Common error codes (from `ErrorCode` enum):

| Code | Constant | Meaning |
|------|----------|---------|
| 401 | `AUTH_EXPIRED` | Token expired |
| 403 | `AUTH_INVALID` | Token invalid |
| 4000 | `CONNECTION_FAILED` | WebSocket failed |
| 4001 | `ROOM_NOT_FOUND` | Room ID doesn't exist |

```typescript
import { ErrorCode } from '@siddhi-life/game-meta'

if (error?.code === ErrorCode.AUTH_EXPIRED) {
  // Redirect to login
}
```

---

## Testing Checklist

Use MetaGameComponent to verify all infrastructure before building custom game UI:

| Feature | How to Test |
|---------|-------------|
| WebSocket connection | Connect, check `isConnected: true` |
| State sync | `sendStatePatch`, open 2 tabs, verify `testData` updates |
| Multiple clients | 2-3 browser tabs in same room, verify `players` |
| Voice chat | `enableVoice: true`, two players, verify audio |
| Voice mute | Toggle, verify other player can't hear |
| Voice volume | Slider, verify level changes |
| Speaking indicator | Speak, verify `speakingParticipants` updates |
| Reconnection | Close/reopen tab, verify state restored |
| Error recovery | Disconnect server, verify `error` populates, `retry` works |

---

## Service Requirements

```
REST + WS: http://localhost:2567
```

Required endpoints:
- `GET  /auth/token` — auth token
- `GET  /lobby` — list rooms
- `POST /lobby/create` — create room
- Colyseus WebSocket on same port
