# @siddhi-life/game-meta

**Version:** 1.4.0  
**Role:** Shared infrastructure package + reference game implementation

Game teams install this package and get WebSocket rooms, voice chat, and state sync for free. They write game logic; `game-meta` handles everything else.

---

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Package Structure](#package-structure)
- [Public API](#public-api)
- [GameProps Contract](#gameprops-contract)
- [GameEvent Types](#gameevent-types)
- [Testing](#testing)
- [Documentation Map](#documentation-map)

---

## Installation

```bash
npm install @siddhi-life/game-meta
```

**Peer Dependencies:**
- React >= 18.0.0
- `colyseus.js`
- `livekit-client`

---

## Quick Start

### Using as a Game Component (loaded by game-loader)

```typescript
// Your game's index.ts — the only contract you need to satisfy
import MyGame from './MyGame.js'

export const metadata = {
  id: 'my-game',
  name: 'My Game',
  description: 'Does cool things',
  minPlayers: 1,
  maxPlayers: 4,
}

export default MyGame
```

```typescript
// MyGame.tsx — use the hook, focus on game logic
import { useGameRoom } from '@siddhi-life/game-meta'
import type { GameProps } from '@siddhi-life/game-meta'

export default function MyGame({ serverUrl, token, roomId, onExit, onEvent }: GameProps) {
  const { isConnected, players, testData, sendStatePatch, latency } = useGameRoom({
    serverUrl,  // always comes from GameProps — never hardcode
    token,
    roomId,
    gameId: 'my-game',
    onEvent,
  })

  return (
    <div>
      <p>Connected: {isConnected ? 'Yes' : 'No'} | Latency: {latency ?? '-'}ms</p>
      <p>Players: {players.length}</p>
      <button onClick={() => sendStatePatch('move', JSON.stringify({ x: 1, y: 2 }))}>
        Make Move
      </button>
    </div>
  )
}
```

### Using MetaGameComponent (pre-built reference UI)

```typescript
import MetaGameComponent from '@siddhi-life/game-meta'

// Typically loaded by game-loader — not mounted directly
<MetaGameComponent
  serverUrl={serverUrl}   // from game-loader via GameProps
  token={token}
  roomId={roomId}
  gameId="meta-game"
  enableVoice={false}
  onExit={() => console.log('exited')}
  onEvent={(event) => console.log('event:', event)}
/>
```

---

## Package Structure

```
packages/game-meta/
├── src/
│   ├── index.ts                    # Public exports (see below)
│   ├── MetaGameComponent.tsx       # Reference game UI
│   ├── types.ts                    # GameProps, GameEvent, PlayerInfo
│   ├── connection/
│   │   ├── ColyseusRoomConnection.ts     # Low-level WebSocket wrapper
│   │   └── GameRoomConnectionManager.ts  # Module-level singleton
│   ├── context/
│   │   └── GameConnectionProvider.tsx    # React context (wraps useGameRoom)
│   ├── hooks/
│   │   ├── useGameRoom.ts          # Primary React hook
│   │   └── useVoice.ts             # LiveKit voice hook
│   ├── components/                 # MetaGame UI sub-components
│   │   ├── StatusBar.tsx
│   │   ├── StatsGrid.tsx
│   │   ├── PlayerList.tsx
│   │   ├── StateSyncPanel.tsx
│   │   ├── LatencyPanel.tsx
│   │   ├── VoiceTokenPanel.tsx
│   │   ├── VoiceControlPanel.tsx
│   │   ├── ExitButton.tsx
│   │   └── DebugPanel.tsx
│   ├── types/
│   │   ├── connection.ts           # Internal connection lifecycle types
│   │   └── errors.ts               # ErrorCode enum
│   └── utils/
│       └── logger.ts               # GameLogger utility
├── dev/
│   └── dev-test.tsx                # Browser dev harness (not shipped)
├── test/                           # Vitest test suite
├── package.json
└── README.md
```

---

## Public API

All public exports are available from the package root:

```typescript
import {
  // Default export — MetaGame reference component
  MetaGameComponent,

  // Hooks — what game teams use
  useGameRoom,
  useVoice,

  // Advanced — singleton manager (vanilla JS or custom wiring)
  GameRoomConnectionManager,

  // Types
  type GameProps,
  type GameEvent,
  type GameComponent,
  type GameMetadata,
  type PlayerInfo,

  // Error codes
  ErrorCode,
  type ErrorCategory,
  type GameError,

  // Debug
  GameLogger,
} from '@siddhi-life/game-meta'
```

**Do not import from internal paths** (`/src/hooks/useGameRoom`, `/hooks/useGameRoom`, etc.) — use the package root.

---

## GameProps Contract

Every game component receives these props from `game-loader`. Game teams must not hardcode or fetch any of these values:

```typescript
interface GameProps {
  serverUrl: string         // game-loader provides this — never hardcode
  token: string             // auth JWT
  roomId?: string           // provided to join existing; omit to create new
  roomPassword?: string     // reserved for private rooms (future)
  onExit: () => void        // call exactly once when game ends
  onEvent: (event: GameEvent) => void  // emit lifecycle events to game-loader
}
```

---

## GameEvent Types

`GameEvent` is a strict discriminated union. All fields are required — no `?` optional payload fields:

```typescript
type GameEvent =
  | { type: 'START';     payload: { roomId: string; sessionId: string } }
  | { type: 'END';       payload: { reason: string; code: number } }
  | { type: 'ERROR';     payload: { code: number; message: string } }
  | { type: 'ROOM_INFO'; payload: Record<string, unknown> }
```

Use TypeScript narrowing when handling events — the type system guarantees payload shape:

```typescript
const handleEvent = (event: GameEvent) => {
  switch (event.type) {
    case 'START':
      // event.payload.roomId and event.payload.sessionId are strings
      console.log('Room joined:', event.payload.roomId)
      break
    case 'END':
      // event.payload.reason is string, event.payload.code is number
      console.log('Ended:', event.payload.reason, event.payload.code)
      break
    case 'ERROR':
      console.error('Error', event.payload.code, event.payload.message)
      break
    case 'ROOM_INFO':
      // event.payload is Record<string, unknown>
      break
  }
}
```

---

## Package Naming Convention

All game packages follow: `@siddhi-life/game-[name]`

| Package | Purpose |
|---------|---------|
| `@siddhi-life/game-meta` | This package — infrastructure + reference implementation |
| `@siddhi-life/game-tictactoe` | Tic-Tac-Toe (future) |
| `@siddhi-life/game-sacred-reading` | Sacred reading game |

---

## Testing

```bash
cd packages/game-meta
npm test
```

**Test coverage:**
- `ColyseusRoomConnection.test.ts` — WebSocket wrapper
- `GameRoomConnectionManager.test.ts` — singleton, StrictMode, deduplication
- `useGameRoom.test.tsx` — hook state machine, events, retry
- `useVoice.test.tsx` — LiveKit connection, audio tracks, mute controls
- `GameConnectionProvider.test.tsx` — context provider wiring

---

## Documentation Map

| Document | Audience | Contents |
|----------|----------|----------|
| **README.md** (this file) | Anyone | Overview, quick start, API |
| [INTEGRATION.md](./INTEGRATION.md) | PWA teams, Game devs | GameProps contract, hooks API, voice |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | All devs | Connection layers, StrictMode, design decisions |
| [AGENT-GUIDE.md](./AGENT-GUIDE.md) | AI agents, Game devs | Step-by-step new game creation |
| [DEV.md](./DEV.md) | Game devs | Local dev workflow, multi-tab testing |
| [GAME-STARTER.md](./GAME-STARTER.md) | Game devs | Create new game repo from scratch |
