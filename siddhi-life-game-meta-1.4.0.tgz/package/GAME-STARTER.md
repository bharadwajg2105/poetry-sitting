# Game Starter Guide

How to build a Siddhi game from scratch.

---

## What a game is

A game is a React component package that:
- Receives `GameProps` from the PWA shell (token, serverUrl, roomId, callbacks)
- Uses `@siddhi-life/game-meta` to connect to the game server and handle voice
- Fires `GameEvent` to report lifecycle to the shell
- Is published to the GitLab npm registry so the shell can dynamically import it

The server side is generic — you write **zero server code**. The Siddhi game service handles all rooms.

---

## Registry access

All `@siddhi-life` packages are on a private GitLab registry. You need a GitLab Personal Access Token (PAT) to install them.

**Get a token:**
1. Go to GitLab → your avatar → Edit profile → Access tokens
2. Create a token with **`read_api`** scope
3. Copy it — you only see it once

**Create `.npmrc` in your project root (do this before `npm install`):**

```
@siddhi-life:registry=https://gitlab.com/api/v4/projects/82447013/packages/npm/
//gitlab.com/api/v4/projects/82447013/packages/npm/:_authToken=YOUR_GITLAB_PAT
```

Replace `YOUR_GITLAB_PAT` with your token. Never commit this file — add `.npmrc` to `.gitignore`.

---

## Step-by-step setup

### 1. Initialize

```bash
mkdir game-my-game && cd game-my-game
npm init -y
```

Set `"name"` in package.json to `@siddhi-life/game-my-game` and `"type"` to `"module"`.

### 2. Create `.npmrc`

```
@siddhi-life:registry=https://gitlab.com/api/v4/projects/82447013/packages/npm/
//gitlab.com/api/v4/projects/82447013/packages/npm/:_authToken=YOUR_GITLAB_PAT
```

### 3. Install dependencies

```bash
npm install @siddhi-life/game-meta
npm install -D vite typescript react react-dom @types/react @vitejs/plugin-react
```

### 4. `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noEmit": true,
    "skipLibCheck": true
  },
  "include": ["src"]
}
```

### 5. `vite.config.ts`

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    lib: {
      entry: 'src/index.ts',
      formats: ['es'],
      fileName: 'index',
    },
    rollupOptions: {
      external: ['react', 'react-dom', '@siddhi-life/game-meta'],
    },
  },
})
```

### 6. `src/index.ts` (package entry point)

```typescript
export { default } from './MyGame'
export const metadata = {
  id: 'my-game',
  name: 'My Game',
  description: 'What this game is about',
  minPlayers: 1,
  maxPlayers: 10,
}
```

### 7. `src/MyGame.tsx` (the game component)

This is the contract the shell expects. Copy this exactly and fill in your logic:

```typescript
import { useCallback } from 'react'
import { useGameRoom } from '@siddhi-life/game-meta'
import type { GameProps, GameEvent } from '@siddhi-life/game-meta'

export default function MyGame({ serverUrl, token, roomId, onExit, onEvent }: GameProps) {
  const handleEvent = useCallback((event: GameEvent) => {
    // Forward all events to the shell
    onEvent(event)

    // React to specific events
    if (event.type === 'END') {
      onExit()
    }
  }, [onEvent, onExit])

  const {
    players,
    state,
    sendStatePatch,
    disconnect,
    isConnected,
  } = useGameRoom({
    serverUrl,
    token,
    roomId,
    gameId: 'my-game',        // must match your registration id
    enableVoice: false,        // set true to enable LiveKit voice
    onEvent: handleEvent,
  })

  if (!isConnected) {
    return <div>Connecting...</div>
  }

  return (
    <div>
      <p>Players: {players.length}</p>
      {/* your game UI */}
    </div>
  )
}
```

### 8. `index.html` (for local dev only)

```html
<!DOCTYPE html>
<html lang="en">
  <head><meta charset="UTF-8" /><title>My Game Dev</title></head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/dev.tsx"></script>
  </body>
</html>
```

### 9. `src/dev.tsx` (local dev harness — not shipped)

```typescript
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import MyGame from './MyGame'

// Get a real JWT from the Siddhi auth service, or paste one here for local dev
const DEV_TOKEN = 'paste-jwt-here'
const DEV_SERVER = 'ws://localhost:2567'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <MyGame
      serverUrl={DEV_SERVER}
      token={DEV_TOKEN}
      roomId={undefined}
      onExit={() => console.log('Game exited')}
      onEvent={(e) => console.log('Event:', e)}
    />
  </StrictMode>
)
```

### 10. Run

```bash
npm run dev
```

---

## GameProps contract

The shell passes these props to your component. Do not hardcode any of them:

```typescript
interface GameProps {
  serverUrl: string   // WebSocket URL to the game service — use exactly as given
  token: string       // Siddhi JWT — pass to useGameRoom, never inspect or store
  roomId?: string     // Room to join. Undefined = create new room
  onExit: () => void  // Call when the game session ends (user exits, leader ends, etc.)
  onEvent: (event: GameEvent) => void  // Forward all GameEvents to the shell
}
```

## GameEvent contract

You must fire these events at the right moments via `onEvent`:

| Event | When to fire | Required payload |
|-------|-------------|------------------|
| `START` | Immediately after Colyseus room JOIN is confirmed | `{ roomId: string, sessionId: string }` |
| `END` | When the session ends normally | `{ reason: string, code: number }` |
| `ERROR` | On unrecoverable error | `{ code: number, message: string }` |
| `ROOM_INFO` | Anytime you want to surface room state to the shell | `Record<string, unknown>` |

`useGameRoom` fires `START`, `END`, and `ERROR` automatically. You only need to forward the `onEvent` callback — see the example above.

---

## Voice

To enable voice, set `enableVoice: true` in `useGameRoom`. The hook handles LiveKit token negotiation and returns `voiceToken` and the `useVoice` hook for microphone control.

```typescript
import { useGameRoom, useVoice } from '@siddhi-life/game-meta'

const { voiceToken, ...rest } = useGameRoom({ ..., enableVoice: true })
const { isMuted, toggleMute, participants } = useVoice(voiceToken)
```

See [INTEGRATION.md](./INTEGRATION.md) for full voice API docs.

---

## Publishing your game

Once your game is ready to integrate into the PWA, publish it to the GitLab registry:

**`package.json`** — add:
```json
"publishConfig": {
  "registry": "https://gitlab.com/api/v4/projects/82447013/packages/npm/",
  "access": "restricted"
}
```

Then:
```bash
npm run build
npm publish
```

After publishing, see [GAME-REGISTRATION.md](../../GAME-REGISTRATION.md) to get your game added to the PWA.

---

## Troubleshooting

**`npm install` gives 401/403**
- `.npmrc` is missing or the token is wrong
- GitLab PAT must have `read_api` scope
- Token may have expired — generate a new one

**`useGameRoom` never fires START**
- Check `serverUrl` is reachable (`ws://` for local, `wss://` for production)
- Check `token` is a valid Siddhi JWT (not expired)
- The game server must be running

**Microphone not working**
- Browser requires `https://` or `localhost` for mic access
- User must grant permission
